package com.capstone.pulih.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.capstone.pulih.data.repository.Repository

class InputDataViewModel (private val repository: Repository) :ViewModel() {

}