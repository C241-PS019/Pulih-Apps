package com.capstone.pulih.utils

class AuthConstant {
    companion object{
        const val ID = "ID"
        const val TOKEN = "TOKEN"
        const val UID = "UID"
        const val NICK = "NICK"
        const val NAMA = "NAMA"
        const val UNIV = "UNIVERSITAS"
        const val IS_FROM_EDIT = "IS_FROM_EDIT"
        const val ONBOARDING = "ONBOARDING"
        const val KONSELOR_ID = "KONSELOR_ID"
        const val NAMA_KONSELOR = "NAMA_KONSELOR"
        const val ROLE = "ROLE"
    }
}